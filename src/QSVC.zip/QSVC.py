#!/usr/bin/env python3

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.datasets import load_iris
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.feature_selection import SelectKBest, f_classif
from sklearn.svm import SVC
from sklearn.metrics import (
    accuracy_score, precision_recall_fscore_support,
    confusion_matrix, roc_auc_score
)
import time
import warnings

warnings.filterwarnings('ignore')

try:
    from qiskit import QuantumCircuit
    from qiskit.circuit.library import ZZFeatureMap, ZFeatureMap, PauliFeatureMap, RealAmplitudes, EfficientSU2
    from qiskit.primitives import Sampler
    from qiskit.circuit import Parameter, ParameterVector
    from qiskit_algorithms.optimizers import (
        SPSA, COBYLA
    )
    from qiskit_machine_learning.kernels import (
        FidelityQuantumKernel,
        TrainableFidelityQuantumKernel
    )
    from qiskit_machine_learning.kernels.algorithms import QuantumKernelTrainer
    from qiskit_machine_learning.algorithms import QSVC

    QISKIT_AVAILABLE = True
    print("Qiskit successfully imported!")

except ImportError as e:
    print(f"Qiskit not available: {e}")
    QISKIT_AVAILABLE = False


def _get_all_optimizers():
    optimizers = {
        'SPSA': SPSA(maxiter=15, learning_rate=0.1, perturbation=0.01),
        'COBYLA': COBYLA(maxiter=15)
    }

    return optimizers


class CompleteQuantumClassifier:

    def __init__(self, add_noise=False, noise_level=2.0, random_state=42):
        self.training_df = None
        self.summary_df = None
        self.random_state = random_state
        self.add_noise = add_noise
        self.noise_level = noise_level
        self.results = {}

        self._load_and_preprocess_data()


        self.binary_problems = {
            'Setosa_vs_Rest': {'target_class': 0, 'name': 'Setosa vs (Versicolor + Virginica)'},
            'Versicolor_vs_Rest': {'target_class': 1, 'name': 'Versicolor vs (Setosa + Virginica)'},
            'Virginica_vs_Rest': {'target_class': 2, 'name': 'Virginica vs (Setosa + Versicolor)'}
        }


        self.classical_kernels = ['rbf', 'poly', 'linear']

        if QISKIT_AVAILABLE:
            self.feature_maps = self._get_feature_maps()
            self.optimizers = _get_all_optimizers()

    def _load_and_preprocess_data(self):
        iris = load_iris()
        X, y = iris.data, iris.target


        if self.add_noise:
            np.random.seed(self.random_state)
            noise = np.random.normal(0, self.noise_level, X.shape)
            X = X + noise

        selector = SelectKBest(score_func=f_classif, k=2)
        X_selected = selector.fit_transform(X, y)

        self.X_full = X
        self.X_selected = X_selected
        self.y = y
        self.feature_names = [iris.feature_names[i] for i in selector.get_support(indices=True)]

        print(f"Selected features: {self.feature_names}")
        print(f"Dataset shape: {X_selected.shape}")
        if self.add_noise:
            print(f"Added Gaussian noise (σ={self.noise_level})")

    def _get_feature_maps(self):
        num_features = 2

        fixed_maps = {}
        try:
            fixed_maps = {
                'ZZFeatureMap': ZZFeatureMap(feature_dimension=num_features, reps=2),
                'ZFeatureMap': ZFeatureMap(feature_dimension=num_features, reps=2),
                'PauliFeatureMap': PauliFeatureMap(feature_dimension=num_features, reps=2, paulis=['Z', 'ZZ'])
            }
            print("Fixed feature maps created successfully!")
        except Exception as e:
            print(f"Error creating fixed feature maps: {e}")

        trainable_maps = {}
        try:
            qc_zz = QuantumCircuit(num_features)
            input_params_zz = ParameterVector("x", num_features)
            theta_params_zz = ParameterVector("θ", num_features * 3)

            for i in range(num_features):
                qc_zz.ry(theta_params_zz[i], i)

            for i in range(num_features):
                qc_zz.rz(input_params_zz[i], i)

            for i in range(num_features - 1):
                qc_zz.cx(i, i + 1)
                qc_zz.rz(input_params_zz[i] * input_params_zz[i + 1], i + 1)
                qc_zz.cx(i, i + 1)

            for i in range(num_features):
                qc_zz.ry(theta_params_zz[num_features + i], i)
                qc_zz.rz(theta_params_zz[2 * num_features + i], i)

            trainable_maps['Trainable_ZZ'] = {
                'circuit': qc_zz,
                'input_params': input_params_zz,
                'training_params': theta_params_zz
            }

            qc_z = QuantumCircuit(num_features)
            input_params_z = ParameterVector("x", num_features)
            theta_params_z = ParameterVector("θ", num_features * 2)

            for i in range(num_features):
                qc_z.ry(theta_params_z[i], i)

            for i in range(num_features):
                qc_z.rz(input_params_z[i], i)

            for i in range(num_features):
                qc_z.ry(theta_params_z[num_features + i], i)

            trainable_maps['Trainable_Z'] = {
                'circuit': qc_z,
                'input_params': input_params_z,
                'training_params': theta_params_z
            }

            qc_pauli = QuantumCircuit(num_features)
            input_params_pauli = ParameterVector("x", num_features)
            theta_params_pauli = ParameterVector("θ", num_features * 4)

            for i in range(num_features):
                qc_pauli.ry(theta_params_pauli[i], i)

            for i in range(num_features):
                qc_pauli.rz(input_params_pauli[i], i)
                qc_pauli.rx(theta_params_pauli[num_features + i], i)

            for i in range(num_features - 1):
                qc_pauli.cx(i, i + 1)
                qc_pauli.rz(input_params_pauli[i] * input_params_pauli[i + 1], i + 1)
                qc_pauli.cx(i, i + 1)

            for i in range(num_features):
                qc_pauli.ry(theta_params_pauli[2 * num_features + i], i)
                qc_pauli.rz(theta_params_pauli[3 * num_features + i], i)

            trainable_maps['Trainable_Pauli'] = {
                'circuit': qc_pauli,
                'input_params': input_params_pauli,
                'training_params': theta_params_pauli
            }

        except Exception as e:
            print(f"Errore nella creazione delle feature map: {e}")

        return {'fixed': fixed_maps, 'trainable': trainable_maps}

    def _create_binary_dataset(self, problem_key):
        target_class = self.binary_problems[problem_key]['target_class']

        y_binary = (self.y == target_class).astype(int)

        X_train, X_test, y_train, y_test = train_test_split(
            self.X_selected, y_binary, test_size=0.3,
            random_state=self.random_state, stratify=y_binary
        )

        scaler = StandardScaler()
        X_train_scaled = scaler.fit_transform(X_train)
        X_test_scaled = scaler.transform(X_test)

        return X_train_scaled, X_test_scaled, y_train, y_test, scaler

    def _evaluate_model(self, y_true, y_pred, y_prob=None):
        metrics = {'accuracy': accuracy_score(y_true, y_pred)}

        precision, recall, f1, _ = precision_recall_fscore_support(y_true, y_pred, average='binary')
        metrics['precision'] = precision
        metrics['recall'] = recall
        metrics['f1_score'] = f1

        if y_prob is not None:
            try:
                metrics['auc_roc'] = roc_auc_score(y_true, y_prob)
            except ValueError:
                metrics['auc_roc'] = 0.0
        else:
            metrics['auc_roc'] = 0.0

        metrics['confusion_matrix'] = confusion_matrix(y_true, y_pred)

        return metrics

    def train_classical_svm(self, problem_key):
        print(f"\n=== Classical SVM: {self.binary_problems[problem_key]['name']} ===")

        X_train, X_test, y_train, y_test, scaler = self._create_binary_dataset(problem_key)

        classical_results = {}

        for kernel in self.classical_kernels:
            print(f"\nTraining SVM with {kernel} kernel")

            start_time = time.time()

            if kernel == 'poly':
                svm = SVC(kernel=kernel, degree=3, probability=True, random_state=self.random_state)
            else:
                svm = SVC(kernel=kernel, probability=True, random_state=self.random_state)

            svm.fit(X_train, y_train)

            training_time = time.time() - start_time

            y_train_pred = svm.predict(X_train)
            y_test_pred = svm.predict(X_test)
            y_test_prob = svm.predict_proba(X_test)[:, 1]

            train_metrics = self._evaluate_model(y_train, y_train_pred)
            test_metrics = self._evaluate_model(y_test, y_test_pred, y_test_prob)

            classical_results[kernel] = {
                'model': svm,
                'training_time': training_time,
                'train_metrics': train_metrics,
                'test_metrics': test_metrics,
                'y_test': y_test,
                'y_test_pred': y_test_pred,
                'y_test_prob': y_test_prob,
                'optimizer': 'N/A'
            }

            print(f"  Training time: {training_time:.3f}s")
            print(f"  Test accuracy: {test_metrics['accuracy']:.3f}")
            print(f"  Test AUC-ROC: {test_metrics['auc_roc']:.3f}")

        return classical_results

    def train_fixed_quantum_svm(self, problem_key):
        print(f"\n=== Fixed Quantum SVM: {self.binary_problems[problem_key]['name']} ===")

        X_train, X_test, y_train, y_test, scaler = self._create_binary_dataset(problem_key)

        fixed_quantum_results = {}

        for fm_name, feature_map in self.feature_maps['fixed'].items():
            print(f"\nTraining QSVM with fixed {fm_name}...")

            try:
                start_time = time.time()

                kernel = FidelityQuantumKernel(feature_map=feature_map)

                qsvc = QSVC(quantum_kernel=kernel)

                qsvc.fit(X_train, y_train)

                training_time = time.time() - start_time

                y_train_pred = qsvc.predict(X_train)
                y_test_pred = qsvc.predict(X_test)

                try:
                    y_test_scores = qsvc.decision_function(X_test)
                    y_test_prob = 1 / (1 + np.exp(-y_test_scores))
                except Exception as prob_error:
                    print(f"    Impossibile calcolare le probabilità: {prob_error}")
                    y_test_prob = None

                train_metrics = self._evaluate_model(y_train, y_train_pred)
                test_metrics = self._evaluate_model(y_test, y_test_pred, y_test_prob)

                config_name = f"Fixed_{fm_name}"
                fixed_quantum_results[config_name] = {
                    'model': qsvc,
                    'kernel': kernel,
                    'training_time': training_time,
                    'train_metrics': train_metrics,
                    'test_metrics': test_metrics,
                    'y_test': y_test,
                    'y_test_pred': y_test_pred,
                    'y_test_prob': y_test_prob,
                    'feature_map': fm_name,
                    'optimizer': 'None'
                }

                print(f"  Training time: {training_time:.3f}s")
                print(f"  Test accuracy: {test_metrics['accuracy']:.3f}")
                if test_metrics.get('auc_roc'):
                    print(f"  Test AUC-ROC: {test_metrics['auc_roc']:.3f}")

            except Exception as e:
                print(f"  Error training fixed {fm_name}: {str(e)}")
                continue

        return fixed_quantum_results


    def train_trainable_quantum_svm(self, problem_key):
        if not QISKIT_AVAILABLE:
            print("Qiskit not available, skipping trainable quantum SVM training")
            return {}

        print(f"\n=== Trainable Quantum SVM: {self.binary_problems[problem_key]['name']} ===")

        X_train, X_test, y_train, y_test, scaler = self._create_binary_dataset(problem_key)

        trainable_quantum_results = {}

        selected_optimizers = ['SPSA', 'COBYLA']

        available_optimizers = {k: v for k, v in self.optimizers.items()
                                if k in selected_optimizers}

        for fm_name, fm_config in self.feature_maps['trainable'].items():
            print(f"\n--- Training {fm_name} with all optimizers ---")

            for opt_name, optimizer in available_optimizers.items():
                config_name = f"{fm_name}_{opt_name}"
                print(f"\nTraining {config_name}...")

                try:
                    start_time = time.time()

                    trainable_kernel = TrainableFidelityQuantumKernel(
                        feature_map=fm_config['circuit'],
                        training_parameters=fm_config['training_params']
                    )

                    kernel_trainer = QuantumKernelTrainer(
                        quantum_kernel=trainable_kernel,
                        loss="svc_loss",
                        optimizer=optimizer
                    )

                    print(f"  Training kernel with {opt_name}...")
                    train_results = kernel_trainer.fit(X_train, y_train)

                    optimized_kernel = train_results.quantum_kernel

                    qsvc = QSVC(quantum_kernel=optimized_kernel)
                    qsvc.fit(X_train, y_train)

                    training_time = time.time() - start_time

                    y_train_pred = qsvc.predict(X_train)
                    y_test_pred = qsvc.predict(X_test)

                    try:
                        y_test_scores = qsvc.decision_function(X_test)
                        y_test_prob = 1 / (1 + np.exp(-y_test_scores))
                    except:
                        y_test_prob = None

                    train_metrics = self._evaluate_model(y_train, y_train_pred)
                    test_metrics = self._evaluate_model(y_test, y_test_pred, y_test_prob)

                    trainable_quantum_results[config_name] = {
                        'model': qsvc,
                        'kernel': optimized_kernel,
                        'training_time': training_time,
                        'train_metrics': train_metrics,
                        'test_metrics': test_metrics,
                        'y_test': y_test,
                        'y_test_pred': y_test_pred,
                        'y_test_prob': y_test_prob,
                        'feature_map': fm_name,
                        'optimizer': opt_name,
                        'optimizer_result': train_results
                    }

                    print(f"  Training time: {training_time:.3f}s")
                    print(f"  Test accuracy: {test_metrics['accuracy']:.3f}")
                    if test_metrics.get('auc_roc'):
                        print(f"  Test AUC-ROC: {test_metrics['auc_roc']:.3f}")

                except Exception as e:
                    print(f"  Errore nel training {config_name}: {str(e)}")
                    continue

        return trainable_quantum_results

    def run_complete_analysis(self):
        print("Starting Complete Quantum vs Classical SVM Analysis")
        print("=" * 80)

        all_results = {}

        for problem_key in self.binary_problems.keys():
            print(f"\n{'=' * 60}")
            print(f"PROBLEM: {self.binary_problems[problem_key]['name']}")
            print(f"{'=' * 60}")

            classical_results = self.train_classical_svm(problem_key)
            fixed_quantum_results = self.train_fixed_quantum_svm(problem_key)
            trainable_quantum_results = self.train_trainable_quantum_svm(problem_key)

            all_results[problem_key] = {
                'classical': classical_results,
                'fixed_quantum': fixed_quantum_results,
                'trainable_quantum': trainable_quantum_results
            }

        self.results = all_results
        return all_results

    def create_comprehensive_summary_report(self):
        print("\n" + "=" * 90)
        print("ANALISI COMPLETA")
        print("=" * 90)

        summary_data = []

        for problem_key, problem_results in self.results.items():
            problem_name = self.binary_problems[problem_key]['name']

            print(f"\n{'-' * 70}")
            print(f"PROBLEM: {problem_name}")
            print(f"{'-' * 70}")

            print("\nRISULTATI SVM CLASSICA:")
            print("-" * 40)
            for kernel, results in problem_results['classical'].items():
                metrics = results['test_metrics']
                print(f"{kernel.upper():>10}: Acc={metrics['accuracy']:.3f}, "
                      f"AUC={metrics.get('auc_roc', 0):.3f}, "
                      f"F1={metrics['f1_score']:.3f}, "
                      f"Time={results['training_time']:.3f}s")

                summary_data.append({
                    'Problem': problem_key,
                    'Type': 'Classical',
                    'Model': kernel,
                    'Optimizer': 'N/A',
                    'Accuracy': metrics['accuracy'],
                    'AUC_ROC': metrics.get('auc_roc', 0),
                    'F1_Score': metrics['f1_score'],
                    'Training_Time': results['training_time']
                })

            if problem_results['fixed_quantum']:
                print("\nRISULTATI FIXED QUANTUM SVM:")
                print("-" * 40)
                for config, results in problem_results['fixed_quantum'].items():
                    metrics = results['test_metrics']
                    print(f"{config[:25]:>25}: Acc={metrics['accuracy']:.3f}, "
                          f"AUC={metrics.get('auc_roc', 0):.3f}, "
                          f"F1={metrics['f1_score']:.3f}, "
                          f"Time={results['training_time']:.3f}s")

                    summary_data.append({
                        'Problem': problem_key,
                        'Type': 'Fixed Quantum',
                        'Model': config,
                        'Optimizer': 'None',
                        'Accuracy': metrics['accuracy'],
                        'AUC_ROC': metrics.get('auc_roc', 0),
                        'F1_Score': metrics['f1_score'],
                        'Training_Time': results['training_time']
                    })

            if problem_results['trainable_quantum']:
                print("\nRISULTATI TRAINABLE QUANTUM SVM:")
                print("-" * 40)
                for config, results in problem_results['trainable_quantum'].items():
                    metrics = results['test_metrics']
                    opt_name = results['optimizer']
                    print(f"{config[:25]:>25}: Acc={metrics['accuracy']:.3f}, "
                          f"AUC={metrics.get('auc_roc', 0):.3f}, "
                          f"F1={metrics['f1_score']:.3f}, "
                          f"Time={results['training_time']:.3f}s, Opt={opt_name}")

                    summary_data.append({
                        'Problem': problem_key,
                        'Type': 'Trainable Quantum',
                        'Model': config,
                        'Optimizer': opt_name,
                        'Accuracy': metrics['accuracy'],
                        'AUC_ROC': metrics.get('auc_roc', 0),
                        'F1_Score': metrics['f1_score'],
                        'Training_Time': results['training_time']
                    })

        self.summary_df = pd.DataFrame(summary_data)

        print(f"\n{'=' * 70}")
        print("PERFORMANCE ANALYSIS")
        print(f"{'=' * 70}")

        if not self.summary_df.empty:
            print("\nAverage Performance by Model Type:")
            type_performance = self.summary_df.groupby('Type').agg({
                'Accuracy': ['mean', 'std', 'max'],
                'AUC_ROC': ['mean', 'std', 'max'],
                'F1_Score': ['mean', 'std', 'max'],
                'Training_Time': ['mean', 'std', 'min']
            }).round(3)
            print(type_performance)

            trainable_df = self.summary_df[self.summary_df['Type'] == 'Trainable Quantum']
            if not trainable_df.empty:
                print(f"\n{'-' * 50}")
                print("Performance del Trainable Quantum Kernel per ogni ottimizzatore:")
                print(f"{'-' * 50}")
                opt_performance = trainable_df.groupby('Optimizer').agg({
                    'Accuracy': ['mean', 'std', 'max'],
                    'Training_Time': ['mean', 'std', 'min']
                }).round(3)
                print(opt_performance)

                print(f"\n{'-' * 50}")
                print("Performance Trainable Quantum Kernel per ogni feature map:")
                print(f"{'-' * 50}")
                trainable_df['FeatureMap'] = trainable_df['Model'].str.extract(r'(Trainable_\w+)_')
                fm_performance = trainable_df.groupby('FeatureMap').agg({
                    'Accuracy': ['mean', 'std', 'max'],
                    'Training_Time': ['mean', 'std', 'min']
                }).round(3)
                print(fm_performance)

            print(f"\n{'=' * 50}")
            print("MIGLIOR PERFORMANCE SECONDO LE METRICHE DI VALUTAZIONE:")
            print(f"{'=' * 50}")

            for metric in ['Accuracy', 'AUC_ROC', 'F1_Score']:
                if metric in self.summary_df.columns:
                    best_idx = self.summary_df[metric].idxmax()
                    best = self.summary_df.loc[best_idx]
                    print(f"\nBest {metric}: {best[metric]:.3f}")
                    print(f"  Model: {best['Model']}")
                    print(f"  Type: {best['Type']}")
                    print(f"  Problem: {best['Problem']}")
                    if best['Optimizer'] != 'N/A':
                        print(f"  Optimizer: {best['Optimizer']}")

                return self.summary_df

    def create_training_set_report(self):
        print("\n" + "=" * 90)
        print("TRAINING SET PERFORMANCE ANALYSIS")
        print("=" * 90)

        training_data = []

        for problem_key, problem_results in self.results.items():
            problem_name = self.binary_problems[problem_key]['name']

            print(f"\n{'-' * 70}")
            print(f"PROBLEM: {problem_name}")
            print(f"{'-' * 70}")

            print("\nCLASSICAL SVM TRAINING RESULTS:")
            print("-" * 40)
            for kernel, results in problem_results['classical'].items():
                metrics = results['train_metrics']
                print(f"{kernel.upper():>10}: Acc={metrics['accuracy']:.3f}, "
                      f"F1={metrics['f1_score']:.3f}, "
                      f"Precision={metrics['precision']:.3f}, "
                      f"Recall={metrics['recall']:.3f}")

                training_data.append({
                    'Problem': problem_key,
                    'Type': 'Classical',
                    'Model': kernel,
                    'Optimizer': 'N/A',
                    'Train_Accuracy': metrics['accuracy'],
                    'Train_F1_Score': metrics['f1_score'],
                    'Train_Precision': metrics['precision'],
                    'Train_Recall': metrics['recall']
                })

            if problem_results['fixed_quantum']:
                print("\nFIXED QUANTUM SVM TRAINING RESULTS:")
                print("-" * 40)
                for config, results in problem_results['fixed_quantum'].items():
                    metrics = results['train_metrics']
                    print(f"{config[:25]:>25}: Acc={metrics['accuracy']:.3f}, "
                          f"F1={metrics['f1_score']:.3f}, "
                          f"Precision={metrics['precision']:.3f}, "
                          f"Recall={metrics['recall']:.3f}")

                    training_data.append({
                        'Problem': problem_key,
                        'Type': 'Fixed Quantum',
                        'Model': config,
                        'Optimizer': 'None',
                        'Train_Accuracy': metrics['accuracy'],
                        'Train_F1_Score': metrics['f1_score'],
                        'Train_Precision': metrics['precision'],
                        'Train_Recall': metrics['recall']
                    })

            if problem_results['trainable_quantum']:
                print("\nTRAINABLE QUANTUM SVM TRAINING RESULTS:")
                print("-" * 40)
                for config, results in problem_results['trainable_quantum'].items():
                    metrics = results['train_metrics']
                    opt_name = results['optimizer']
                    print(f"{config[:25]:>25}: Acc={metrics['accuracy']:.3f}, "
                          f"F1={metrics['f1_score']:.3f}, "
                          f"Precision={metrics['precision']:.3f}, "
                          f"Recall={metrics['recall']:.3f}, Opt={opt_name}")

                    training_data.append({
                        'Problem': problem_key,
                        'Type': 'Trainable Quantum',
                        'Model': config,
                        'Optimizer': opt_name,
                        'Train_Accuracy': metrics['accuracy'],
                        'Train_F1_Score': metrics['f1_score'],
                        'Train_Precision': metrics['precision'],
                        'Train_Recall': metrics['recall']
                    })

        self.training_df = pd.DataFrame(training_data)

        print(f"\n{'=' * 70}")
        print("TRAINING PERFORMANCE SUMMARY")
        print(f"{'=' * 70}")

        if not self.training_df.empty:
            print("\nAverage Training Performance by Model Type:")
            type_performance = self.training_df.groupby('Type').agg({
                'Train_Accuracy': ['mean', 'std', 'max'],
                'Train_F1_Score': ['mean', 'std', 'max'],
                'Train_Precision': ['mean', 'std', 'max'],
                'Train_Recall': ['mean', 'std', 'max']
            }).round(3)
            print(type_performance)

            print(f"\n{'=' * 50}")
            print("BEST TRAINING PERFORMANCE BY METRIC:")
            print(f"{'=' * 50}")

            for metric in ['Train_Accuracy', 'Train_F1_Score', 'Train_Precision', 'Train_Recall']:
                best_idx = self.training_df[metric].idxmax()
                best = self.training_df.loc[best_idx]
                print(f"\nBest {metric.replace('Train_', '')}: {best[metric]:.3f}")
                print(f"  Model: {best['Model']}")
                print(f"  Type: {best['Type']}")
                print(f"  Problem: {best['Problem']}")
                if best['Optimizer'] != 'N/A':
                    print(f"  Optimizer: {best['Optimizer']}")

        return self.training_df

    def create_visualization_plots(self):
        plt.style.use('default')
        sns.set_palette("husl")

        fig, axes = plt.subplots(2, 3, figsize=(18, 12))
        fig.suptitle('Complete Quantum vs Classical SVM Analysis', fontsize=16, fontweight='bold')

        ax1 = axes[0, 0]
        accuracy_by_type = self.summary_df.groupby('Type')['Accuracy'].agg(['mean', 'std']).reset_index()
        bars1 = ax1.bar(accuracy_by_type['Type'], accuracy_by_type['mean'],
                        yerr=accuracy_by_type['std'], capsize=5, alpha=0.7)
        ax1.set_title('Average Accuracy by Model Type')
        ax1.set_ylabel('Accuracy')
        ax1.set_ylim(0, 1.1)
        ax1.tick_params(axis='x', rotation=45)

        for bar, mean_val in zip(bars1, accuracy_by_type['mean']):
            ax1.text(bar.get_x() + bar.get_width() / 2, bar.get_height() + 0.01,
                     f'{mean_val:.3f}', ha='center', va='bottom')

        ax2 = axes[0, 1]
        time_by_type = self.summary_df.groupby('Type')['Training_Time'].agg(['mean', 'std']).reset_index()
        bars2 = ax2.bar(time_by_type['Type'], time_by_type['mean'],
                        yerr=time_by_type['std'], capsize=5, alpha=0.7, color='orange')
        ax2.set_title('Training Time medio per ogni tipo di modello')
        ax2.set_ylabel('Training Time (in secondi)')
        ax2.tick_params(axis='x', rotation=45)
        ax2.set_yscale('log')

        for bar, mean_val in zip(bars2, time_by_type['mean']):
            y_pos = bar.get_height() * 1.1
            ax2.text(bar.get_x() + bar.get_width() / 2, y_pos,
                     f'{mean_val:.2f}s', ha='center', va='bottom')

        ax3 = axes[0, 2]
        f1_by_type = self.summary_df.groupby('Type')['F1_Score'].agg(['mean', 'std']).reset_index()
        bars3 = ax3.bar(f1_by_type['Type'], f1_by_type['mean'],
                        yerr=f1_by_type['std'], capsize=5, alpha=0.7, color='green')
        ax3.set_title('F1 Score medio per ogni tipo di modello')
        ax3.set_ylabel('F1 Score')
        ax3.set_ylim(0, 1.1)
        ax3.tick_params(axis='x', rotation=45)

        for bar, mean_val in zip(bars3, f1_by_type['mean']):
            ax3.text(bar.get_x() + bar.get_width() / 2, bar.get_height() + 0.01,
                     f'{mean_val:.3f}', ha='center', va='bottom')

        ax4 = axes[1, 0]
        trainable_df = self.summary_df[self.summary_df['Type'] == 'Trainable Quantum']
        if not trainable_df.empty:
            opt_performance = trainable_df.groupby('Optimizer')['Accuracy'].agg(
                ['mean', 'std']).reset_index()
            bars4 = ax4.bar(opt_performance['Optimizer'], opt_performance['mean'],
                            yerr=opt_performance['std'], capsize=5, alpha=0.7, color='red')
            ax4.set_title('Performance dell\' Optimizer (Trainable Quantum)')
            ax4.set_ylabel('Accuracy')
            ax4.set_ylim(0, 1.1)
            ax4.tick_params(axis='x', rotation=45)

            for bar, mean_val in zip(bars4, opt_performance['mean']):
                ax4.text(bar.get_x() + bar.get_width() / 2, bar.get_height() + 0.01,
                         f'{mean_val:.3f}', ha='center', va='bottom')
        else:
            ax4.text(0.5, 0.5, 'No Trainable Quantum Data', ha='center', va='center',
                     transform=ax4.transAxes)
            ax4.set_title('Optimizer Performance (No Data)')

        ax5 = axes[1, 1]
        problem_performance = self.summary_df.groupby('Problem')['Accuracy'].agg(
            ['mean', 'std']).reset_index()
        bars5 = ax5.bar(problem_performance['Problem'], problem_performance['mean'],
                        yerr=problem_performance['std'], capsize=5, alpha=0.7, color='purple')
        ax5.set_title('Accuracy media per ogni problema')
        ax5.set_ylabel('Accuracy')
        ax5.set_ylim(0, 1.1)
        ax5.tick_params(axis='x', rotation=45)

        for bar, mean_val in zip(bars5, problem_performance['mean']):
            ax5.text(bar.get_x() + bar.get_width() / 2, bar.get_height() + 0.01,
                     f'{mean_val:.3f}', ha='center', va='bottom')

        ax6 = axes[1, 2]
        colors = {'Classical': 'blue', 'Fixed Quantum': 'orange', 'Trainable Quantum': 'red'}
        for model_type in self.summary_df['Type'].unique():
            type_data = self.summary_df[self.summary_df['Type'] == model_type]
            ax6.scatter(type_data['Training_Time'], type_data['Accuracy'],
                        label=model_type, alpha=0.7, color=colors.get(model_type, 'gray'), s=50)
        ax6.set_xlabel('Training Time (in secondi)')
        ax6.set_ylabel('Accuracy')
        ax6.set_title('Accuracy vs Training Time')
        ax6.legend()
        ax6.set_xscale('log')
        ax6.grid(True, alpha=0.3)

        plt.tight_layout()
        plt.show()

        if QISKIT_AVAILABLE and not trainable_df.empty:
            self._create_detailed_quantum_plot()

    def _create_detailed_quantum_plot(self):
        fig, axes = plt.subplots(1, 2, figsize=(15, 6))
        fig.suptitle('Analisi dettagliata dei modelli quantistici', fontsize=14, fontweight='bold')

        quantum_df = self.summary_df[self.summary_df['Type'].str.contains('Quantum')]

        if not quantum_df.empty:
            ax1 = axes[0]
            quantum_models = quantum_df['Model'].unique()[:10]
            model_acc = []
            model_names = []
            colors = []

            for model in quantum_models:
                model_data = quantum_df[quantum_df['Model'] == model]
                if not model_data.empty:
                    acc = model_data['Accuracy'].iloc[0]
                    model_acc.append(acc)
                    model_names.append(model[:20])
                    if 'Fixed' in model:
                        colors.append('lightblue')
                    else:
                        colors.append('lightcoral')

            bars = ax1.barh(range(len(model_names)), model_acc, color=colors, alpha=0.7)
            ax1.set_yticks(range(len(model_names)))
            ax1.set_yticklabels(model_names)
            ax1.set_xlabel('Accuracy')
            ax1.set_title('Comfronto tra performance dei Quantum Model')
            ax1.set_xlim(0, 1.1)

            for i, (bar, acc) in enumerate(zip(bars, model_acc)):
                ax1.text(bar.get_width() + 0.01, bar.get_y() + bar.get_height() / 2,
                         f'{acc:.3f}', va='center')

            ax2 = axes[1]
            trainable_df = quantum_df[quantum_df['Type'] == 'Trainable Quantum']
            if not trainable_df.empty:
                trainable_df['FeatureMap'] = trainable_df['Model'].str.extract(r'(Trainable_\w+)_')
                fm_performance = trainable_df.groupby('FeatureMap')['Accuracy'].agg(
                    ['mean', 'std']).reset_index()

                ax2.bar(fm_performance['FeatureMap'], fm_performance['mean'],
                        yerr=fm_performance['std'], capsize=5, alpha=0.7, color='mediumpurple')
                ax2.set_title('Feature Map Performance (Trainable)')
                ax2.set_ylabel('Average Accuracy')
                ax2.set_ylim(0, 1.1)
                ax2.tick_params(axis='x', rotation=45)
            else:
                ax2.text(0.5, 0.5, 'No Trainable Quantum Data', ha='center', va='center',
                         transform=ax2.transAxes)

        plt.tight_layout()
        plt.show()


    def save_results_to_file(self, filename="quantum_svm_results.csv"):
        if hasattr(self, 'summary_df') and not self.summary_df.empty:
            df_to_save = self.summary_df.copy()
            df_to_save['Training_Time'] = df_to_save['Training_Time'].apply(lambda x: f"{x:.6f}")
            numeric_columns = ['Accuracy', 'AUC_ROC', 'F1_Score']
            for col in numeric_columns:
                if col in df_to_save.columns:
                    df_to_save[col] = df_to_save[col].apply(lambda x: f"{x:.6f}")

            df_to_save.to_csv(filename, index=False, float_format='%.6f')
            print(f"Results saved to {filename}")

    def save_training_results_to_file(self, filename="quantum_svm_training_results.csv"):
        if hasattr(self, 'training_df') and not self.training_df.empty:
            df_to_save = self.training_df.copy()
            numeric_columns = ['Train_Accuracy', 'Train_F1_Score', 'Train_Precision', 'Train_Recall']
            for col in numeric_columns:
                if col in df_to_save.columns:
                    df_to_save[col] = df_to_save[col].apply(lambda x: f"{x:.6f}")

            df_to_save.to_csv(filename, index=False, float_format='%.6f')
            print(f"Training results saved to {filename}")


    def print_model_comparison_table(self):
        if not hasattr(self, 'summary_df') or self.summary_df.empty:
            print("No results available. Run analysis first.")
            return

        print(f"\n{'=' * 120}")
        print("TABELLA DETTAGLIATA DI CONFRONTO DEI MODELLI")
        print(f"{'=' * 120}")

        pd.set_option('display.max_columns', None)
        pd.set_option('display.width', None)
        pd.set_option('display.max_colwidth', 25)

        sorted_df = self.summary_df.sort_values('Accuracy', ascending=False)

        print(sorted_df.to_string(index=False, float_format='%.3f'))

        pd.reset_option('display.max_columns')
        pd.reset_option('display.width')
        pd.reset_option('display.max_colwidth')

def main():
    print("Analisi completa di classificazione SVM quantistica vs classica")
    print("=" * 80)
    print("Questa analisi confronta:")
    print("1. SVM classica con diversi kernels (RBF, Polynomial, Linear)")
    print("2. Fixed Quantum SVM con feature map predefinite")
    print("3. Trainable Quantum SVM con ottimizzazione dei parametri")
    print("=" * 80)

    try:
        add_noise = input("Vuoi aggiungere rumore? (y/n): ").lower() == 'y'
        noise_level = 2.0 if add_noise else 0.0

        classifier = CompleteQuantumClassifier(add_noise=add_noise, noise_level=noise_level)

        print("\nIniziando l'analisi completa...")
        classifier.run_complete_analysis()

        print("\nGenerando report di sintesi...")
        summary_df = classifier.create_comprehensive_summary_report()

        print("\nCreando i grafici di visualizzazione...")
        classifier.create_visualization_plots()

        classifier.print_model_comparison_table()

        save_results = input("\nSalvare i risultati in un file CSV? (y/n): ").lower() == 'y'
        if save_results:
            classifier.save_results_to_file()

        classifier.create_training_set_report()
        save_training = input("\nSalvare i risultati sul training in un file CSV? (y/n): ").lower() == 'y'
        if save_training:
            classifier.save_training_results_to_file()

        print("\n" + "=" * 80)
        print("ANALISI COMPLETA!")
        print("=" * 80)
        print("Key findings:")

        if not summary_df.empty:
            best_classical = summary_df[summary_df['Type'] == 'Classical']['Accuracy'].max()
            best_quantum = summary_df[summary_df['Type'].str.contains('Quantum')]['Accuracy'].max()

            print(f"- Miglior accuratezza per SVM Classica: {best_classical:.3f}")
            if not pd.isna(best_quantum):
                print(f"- Miglior accuratezza per SVM Quantistica: {best_quantum:.3f}")
                if best_quantum > best_classical:
                    print("- La SVM Quantistica ha raggiunto risultati migliori!")
                elif abs(best_quantum - best_classical) < 0.01:
                    print("- SVM Quantistica e Classica  hanno avuto gli stessi risultati.")
                else:
                    print("- SVM Classica ha raggiunto risultati migliori.")

            avg_classical_time = summary_df[summary_df['Type'] == 'Classical']['Training_Time'].mean()
            avg_quantum_time = summary_df[summary_df['Type'].str.contains('Quantum')][
                'Training_Time'].mean()

            print(f"- Training Time medio SVM classica: {avg_classical_time:.3f}s")
            if not pd.isna(avg_quantum_time):
                print(f"- Training Time medio SVM quantistica: {avg_quantum_time:.3f}s")

        return classifier

    except Exception as e:
        print(f"\nErrore durante l'analisi: {str(e)}")
        import traceback
        traceback.print_exc()
        return None


if __name__ == "__main__":
    classifier = main()
